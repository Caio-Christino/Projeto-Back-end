package com.academy.demo.enums;

public enum Papel {
    ROLE_ADMIN,
    ROLE_CLIENTE,
    ROLE_FUNCIONARIO;
    
}
